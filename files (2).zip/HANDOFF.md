# Cathedral Acquisitions — Claude Code Handoff

A complete, runnable Section 8 acquisition pipeline. Extract the tarball into your monorepo and follow this spec.

## What you have

- 82 files. 50 passing tests (38 calc + 12 NSPIRE).
- Schema: 17 tables, 3 views, 2 functions, RLS policies, seeded reference data.
- 9 React pages, navy/teal/gold brand.
- 5 GitHub Actions workflows.
- 4 Supabase Edge Functions.
- 4 issue templates.
- 12 docs files (architecture, lifecycle, 3 playbooks, 3 runbooks, 4 templates).

## File tree

```
cathedral-acquisitions/
├── README.md                              # Setup + usage
├── package.json                           # pnpm workspace
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── netlify.toml
├── .env.example
├── .gitignore
│
├── apps/dashboard/                        # React 19 + Vite + Tailwind
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── index.html
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── index.css                      # Tailwind + brand utilities
│       ├── lib/
│       │   ├── supabase.ts
│       │   ├── api.ts                     # Typed query wrappers
│       │   └── format.ts
│       └── pages/
│           ├── Dashboard.tsx              # KPIs + deadlines + pipeline
│           ├── Deals.tsx                  # Pipeline kanban
│           ├── DealDetail.tsx             # Live calc, capital stack, NSPIRE
│           ├── Inspections.tsx            # NSPIRE checklist generator
│           ├── Tenants.tsx                # Voucher pipeline
│           ├── Compliance.tsx             # Deadline calendar
│           ├── Finances.tsx               # Charts + per-property breakdown
│           ├── Market.tsx                 # Scanner output
│           └── Lenders.tsx                # April 2026 pricing database
│
├── packages/
│   ├── shared-types/src/index.ts          # Domain types
│   ├── calculations/                      # Pure-function math (38 tests)
│   │   ├── src/
│   │   │   ├── mortgage.ts                # P&I, amortization
│   │   │   ├── fha.ts                     # SST, MIP, LTV co-borrower rules
│   │   │   ├── dscr.ts                    # DSCR + pricing tier
│   │   │   ├── capital-stack.ts           # Sources/uses
│   │   │   ├── cashflow.ts                # Performa, NOI, CoC
│   │   │   └── tax.ts                     # Bonus dep, REPS, cost seg
│   │   └── tests/                         # 38 tests
│   └── nspire-engine/                     # 49-item checklist (12 tests)
│       ├── data/nspire-items.json
│       └── src/index.ts                   # generateChecklist + preFailAudit
│
├── supabase/
│   ├── migrations/
│   │   ├── 20260430000001_initial_schema.sql      # 17 tables
│   │   ├── 20260430000002_rls_policies.sql        # Single-tenant
│   │   ├── 20260430000003_views_and_functions.sql # 4 views, 2 fns
│   │   └── 20260430000004_seed_reference_data.sql # 11 states, 7 PHAs, 14 lenders
│   └── functions/
│       ├── deadline-watcher/index.ts
│       ├── market-scan/index.ts
│       ├── nspire-audit/index.ts
│       └── financial-recalc/index.ts
│
├── .github/
│   ├── workflows/
│   │   ├── ci.yml                         # PR typecheck + tests
│   │   ├── deploy.yml                     # Netlify + Supabase push
│   │   ├── daily-deadlines.yml            # 09:00 UTC daily
│   │   ├── weekly-recalc.yml              # 13:00 UTC Sunday
│   │   └── market-scanner.yml             # 11:00 UTC daily
│   └── ISSUE_TEMPLATE/
│       ├── deal.yml
│       ├── lender-application.yml
│       ├── inspection.yml
│       └── tenant-application.yml
│
├── scripts/
│   ├── check-deadlines.ts                 # Posts overdue as Issues
│   ├── portfolio-summary.ts               # Weekly digest
│   ├── market-scan.ts                     # Score + flag listings
│   └── new-deal.sh                        # Interactive deal creation
│
└── docs/
    ├── ARCHITECTURE.md
    ├── DEAL-LIFECYCLE.md
    ├── COMPLIANCE-CALENDAR.md
    ├── playbooks/
    │   ├── fha-house-hack.md              # Cleveland Deal #1 step-by-step
    │   ├── dscr-acquisition.md
    │   └── brrrr.md
    ├── runbooks/
    │   ├── nspire-prep.md                 # Pre-inspection self-audit
    │   ├── rfta-submission.md
    │   └── tenant-screening.md
    └── templates/
        ├── gift-letter.md                 # FHA-compliant
        ├── promissory-note.md             # Cousin scenario
        ├── operating-agreement-multi-member.md
        └── lead-disclosure.md             # Federal 24 CFR 35
```

## Setup commands (run in order)

```bash
# 1. Extract
tar xzf cathedral-acquisitions.tar.gz
cd cathedral-acquisitions

# 2. Install dependencies
pnpm install

# 3. Verify tests pass
pnpm test
# Expected: 50/50 passing

# 4. Set up Supabase (one-time)
npm install -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_ID

# 5. Push schema
supabase db push

# 6. Deploy edge functions
for fn in deadline-watcher market-scan nspire-audit financial-recalc; do
  supabase functions deploy $fn
done

# 7. Configure local env
cp .env.example .env
# Fill in VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY

# 8. Run dashboard
pnpm dev
# Opens http://localhost:5173
```

## GitHub Secrets to add

In repo Settings → Secrets and variables → Actions:

| Secret | Where to get |
|---|---|
| `VITE_SUPABASE_URL` | Supabase dashboard → Settings → API |
| `VITE_SUPABASE_ANON_KEY` | Same place |
| `SUPABASE_URL` | Same as VITE_SUPABASE_URL |
| `SUPABASE_SERVICE_ROLE_KEY` | Same place — under "Project API keys" |
| `SUPABASE_ACCESS_TOKEN` | https://supabase.com/dashboard/account/tokens |
| `SUPABASE_DB_PASSWORD` | Supabase → Settings → Database |
| `SUPABASE_PROJECT_ID` | From your project URL |
| `NETLIFY_AUTH_TOKEN` | Netlify → User settings → Applications |
| `NETLIFY_SITE_ID` | Netlify → Site settings |

Optional:
- `MAILERLITE_API_KEY` for email digests
- `NOTIFY_EMAIL` for digest recipient
- `ZILLOW_API_KEY` if wiring real listing data

## Wire-up tasks (in priority order)

1. **Push to GitHub.** First commit triggers CI (must pass), then deploy.yml runs (deploys dashboard to Netlify).
2. **Verify dashboard renders** at your Netlify URL. Should show empty portfolio.
3. **Create test deal** via the GitHub Issue template "New Deal" or `pnpm deal:new`.
4. **Wire market scanner data source** — `scripts/market-scan.ts:fetchListings()` is a placeholder. Pick:
   - RapidAPI Zillow (~$10/mo)
   - Realtor.com via 3rd-party
   - Direct MLS feed (most expensive but cleanest)
5. **Test deadline-watcher manually:** Trigger workflow_dispatch on `daily-deadlines.yml`. Should create no issues if no deadlines exist.
6. **Add first deadline** via Supabase studio to verify the watcher creates a GitHub Issue when overdue.

## Key tests to verify before shipping to prod

```bash
pnpm test                                 # All 50 tests pass
pnpm typecheck                            # No TS errors
pnpm build                                # Dashboard builds clean
supabase db reset && supabase db push     # Schema applies clean
supabase functions serve deadline-watcher  # Edge function runs locally
```

## Architecture decisions (so you don't have to relitigate)

- **Postgres-first.** Every read is a view query. Every write is a row insert/update. No ORM. Direct supabase-js.
- **pnpm workspace monorepo.** Three packages, one app. Aliases configured in `tsconfig.base.json`.
- **Brand: navy / teal / gold.** Tailwind config has full palette under `cathedral.{navy,teal,gold}`. Use these utility classes throughout.
- **Tests live next to code.** `packages/calculations/tests/` not `__tests__`. Vitest, not Jest.
- **No GraphQL, no tRPC, no React Query.** Just `useEffect` + supabase client. Add React Query in v2 if needed.
- **RLS is permissive single-tenant now.** When portfolio partners join, replace `to authenticated using (true)` with `using (auth.uid() in (select user_id from members where deal_id = deals.id))`-style checks.
- **No auth flow yet.** Dashboard assumes you're authenticated. Add Supabase magic-link auth as v2 task: `import { Auth } from '@supabase/auth-ui-react'`.

## Known gaps (pick up later)

- **Auth UI** not wired. Anonymous + service role only right now.
- **Mobile responsiveness** is OK but not polished for sub-768px viewports.
- **Document upload** UI not built — `documents` table exists but no React upload widget yet.
- **Email/SMS notifications** are placeholders. MailerLite is for marketing; transactional needs Resend/Postmark/SendGrid.
- **Real-time subscriptions** not configured. Uses polling per page load.
- **Test coverage on dashboard pages** is zero. Calc engine + NSPIRE are tested; UI components aren't.

## Cathedral Principle alignment

This system is built **Foundation → Revenue → Systems → Scale**:
- Foundation = the schema. The truth lives there.
- Revenue = the math + the pipeline. Every dollar tracked.
- Systems = the workflows. Daily/weekly automation.
- Scale = RLS-ready, LLC-ready, Series-LLC-ready when you cross 5 doors.

Ship it.
